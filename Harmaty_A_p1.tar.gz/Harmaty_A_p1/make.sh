#!/bin/bash
javac -d bin src/main/java/binghamton/cs575/program1/*.java
