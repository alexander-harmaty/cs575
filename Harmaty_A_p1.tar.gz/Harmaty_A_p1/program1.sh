#!/bin/bash

java -cp ./bin binghamton.cs575.program1.Main "$@"
