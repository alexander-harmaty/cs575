#!/bin/bash

echo "Running with arguments: -m $1 -p $2 -o $3"

java -cp ./bin binghamton.cs575.program1.Main "$@"
