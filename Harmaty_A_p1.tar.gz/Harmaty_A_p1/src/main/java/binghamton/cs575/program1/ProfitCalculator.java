package binghamton.cs575.program1;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

public class ProfitCalculator {
    private int maxProfit = 0;
    private List<Card> bestCombination = new ArrayList<>();
    private long startTime;

    public ProfitCalculator() {
        // Initialize
    }

    public void computeMaxProfit(List<Card> cards, int W) {
        startTime = System.nanoTime();
        exploreSubsets(cards, 0, new ArrayList<>(), 0, W);
    }

    private void exploreSubsets(List<Card> cards, int index, List<Card> currentSubset, int currentSpend, int maxSpend) {
        if (index == cards.size()) {
            updateMaxProfit(currentSubset, currentSpend, maxSpend);
            return;
        }

        Card currentCard = cards.get(index);
        if (currentSpend + currentCard.getPurchasePrice() <= maxSpend) {
            currentSubset.add(currentCard);
            exploreSubsets(cards, index + 1, currentSubset, currentSpend + currentCard.getPurchasePrice(), maxSpend);
            currentSubset.remove(currentSubset.size() - 1); 
        }

        exploreSubsets(cards, index + 1, currentSubset, currentSpend, maxSpend);
    }

    private void updateMaxProfit(List<Card> currentSubset, int currentSpend, int maxSpend) {
        int currentProfit = currentSubset.stream().mapToInt(Card::getProfit).sum();
        if (currentProfit > maxProfit && currentSpend <= maxSpend) {
            maxProfit = currentProfit;
            bestCombination = new ArrayList<>(currentSubset);
        }
    }

    public int getMaxProfit() {
        return maxProfit;
    }

    public List<Card> getBestCombination() {
        return new ArrayList<>(bestCombination);
    }

    public double getElapsedTime() {
        return (System.nanoTime() - startTime) / 1e9;
    }
}
