package binghamton.cs575.program1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileParser {
    public static Map<String, Integer> parseMarketPriceFile(String filename) throws IOException {
        try (Stream<String> lines = Files.lines(Paths.get(filename))) {
            return lines.skip(1) 
                        .map(line -> line.split(" "))
                        .collect(Collectors.toMap(parts -> parts[0], parts -> Integer.parseInt(parts[1])));
        }
    }

    public static List<PriceList> parsePriceListFile(String filename) throws IOException {
        List<String> lineList;
        try (Stream<String> lines = Files.lines(Paths.get(filename))) {
            lineList = lines.collect(Collectors.toList());
        }

        List<PriceList> priceLists = new ArrayList<>();
        for (int i = 0; i < lineList.size(); ) {
            String[] firstLineParts = lineList.get(i++).split(" ");
            int n = Integer.parseInt(firstLineParts[0]);
            int W = Integer.parseInt(firstLineParts[1]);
            List<Card> cards = new ArrayList<>();
            for (int j = 0; j < n; j++, i++) {
                String[] cardParts = lineList.get(i).split(" ");
                cards.add(new Card(cardParts[0], 0, Integer.parseInt(cardParts[1])));
            }
            priceLists.add(new PriceList(cards, W));
        }
        return priceLists;
    }

    public static class PriceList {
        private final List<Card> cards;
        private final int maxSpend;

        public PriceList(List<Card> cards, int maxSpend) {
            this.cards = new ArrayList<>(cards); 
            this.maxSpend = maxSpend;
        }

        public List<Card> getCards() {
            return new ArrayList<>(cards); 
        }

        public int getMaxSpend() {
            return maxSpend;
        }
    }
}
