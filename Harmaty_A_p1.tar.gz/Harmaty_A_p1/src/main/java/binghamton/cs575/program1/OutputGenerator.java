package binghamton.cs575.program1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

public class OutputGenerator {
    public static void generateOutput(String filename, List<FileParser.PriceList> priceLists, Map<String, Integer> marketPrices) throws IOException {
        StringBuilder outputBuilder = new StringBuilder();
        
        for (FileParser.PriceList priceList : priceLists) {
            updateMarketPrices(priceList.getCards(), marketPrices);
            ProfitCalculator calculator = new ProfitCalculator();
            calculator.computeMaxProfit(priceList.getCards(), priceList.getMaxSpend());

            StringJoiner joiner = new StringJoiner(" ")
                    .add(String.valueOf(priceList.getCards().size()))
                    .add(String.valueOf(calculator.getMaxProfit()))
                    .add(String.valueOf(calculator.getBestCombination().size()))
                    .add(String.format("%.6f", calculator.getElapsedTime()));

            outputBuilder.append(joiner).append("\n");
            calculator.getBestCombination().forEach(card -> outputBuilder.append(card.getName()).append("\n"));
        }
        
        Files.write(Paths.get(filename), outputBuilder.toString().getBytes());
    }

    private static void updateMarketPrices(List<Card> cards, Map<String, Integer> marketPrices) {
        cards.forEach(card -> {
            Integer marketPrice = marketPrices.get(card.getName());
            if (marketPrice != null) {
                card.setMarketPrice(marketPrice);
            }
        });
    }
}
