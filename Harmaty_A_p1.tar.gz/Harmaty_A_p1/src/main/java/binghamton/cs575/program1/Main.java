package binghamton.cs575.program1;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        if (args.length != 6) {
            System.err.println("Usage: program1 -m <market-price-file> -p <price-list-file> -o <output-file>");
            System.exit(1);
        }

        String marketPriceFile = args[1];
        String priceListFile = args[3];
        String outputFile = args[5];

        try {
            Map<String, Integer> marketPrices = FileParser.parseMarketPriceFile(marketPriceFile);
            List<FileParser.PriceList> priceLists = FileParser.parsePriceListFile(priceListFile);
            OutputGenerator.generateOutput(outputFile, priceLists, marketPrices);
        } catch (IOException e) {
            System.err.println("Error reading or writing files: " + e.getMessage());
            System.exit(1);
        }
    }
}
