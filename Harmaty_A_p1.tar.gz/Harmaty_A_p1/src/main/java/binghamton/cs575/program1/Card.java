package binghamton.cs575.program1;

public class Card {
    private String name;
    private int marketPrice;
    private int purchasePrice;

    public Card(String name, int marketPrice, int purchasePrice) {
        this.name = name;
        this.marketPrice = marketPrice;
        this.purchasePrice = purchasePrice;
    }

    public String getName() {
        return name;
    }

    public int getMarketPrice() {
        return marketPrice;
    }

    public int getPurchasePrice() {
        return purchasePrice;
    }

    public int getProfit() {
        return marketPrice - purchasePrice;
    }
    
    public void setMarketPrice(int marketPrice) {
        this.marketPrice = marketPrice;
    }
}
