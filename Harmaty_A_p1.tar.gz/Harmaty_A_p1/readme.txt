Java
To compile: javac -d bin src/main/java/binghamton/cs575/program1/*.java
To run: java -cp ./bin binghamton.cs575.program1.Main -m market_price.txt -p price_list.txt -o output.txt
